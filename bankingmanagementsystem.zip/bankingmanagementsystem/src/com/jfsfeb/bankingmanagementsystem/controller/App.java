package com.jfsfeb.bankingmanagementsystem.controller;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.jfsfeb.bankingmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.UserInfoBean;
import com.jfsfeb.bankingmanagementsystem.exception.UserExceptions;
import com.jfsfeb.bankingmanagementsystem.factory.AdminFactory;
import com.jfsfeb.bankingmanagementsystem.factory.UserFactory;
import com.jfsfeb.bankingmanagementsystem.repository.BankingDb;
import com.jfsfeb.bankingmanagementsystem.service.AdminService;
import com.jfsfeb.bankingmanagementsystem.service.UserService;


public class App {
	public static void doReg() {
		BankingDb.addToDb();

		int adminId = 0;
		String adminName = null;
		long adminMobile = 0l;
		String adminEmail = null;
		String adminPassword = null;
		int userId = 0;
		String userName = null;
		long userMobile = 0l;
		String userEmail = null;
		String userPassword = null;
		int userReqId = 0;
		long userAcctNum = 0l;
		double balance = 0f;

		AdminInfoBean adminBean = null;
		UserInfoBean userBean = null;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		do {
			try {
				System.out.println("************Welcome to Bancking management System************");
				System.out.println("Press 1 for Admin Block");
				System.out.println("Press 2 for User Block");
				System.out.println("***********************************");
				int i = scanner.nextInt();
				switch (i) {
				case 1:
					AdminService service = AdminFactory.getAdminServiceImplDaoInstance();

					do {
						try {
							System.out.println("********Welcome To Admin Portal********");
							System.out.println("You Want to Register Press 1");
							System.out.println("You Want to Login Press 2");
							System.out.println("To Exit press 3");
							System.out.println("***********************************");
							int choice = scanner.nextInt();
							switch (choice) {
							case 1:
								System.out.println("********Enter All the details to Register********");

								try {
									System.out.println("Enter ID :");
									adminId = scanner.nextInt();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								System.out.println("Enter Name :");
								adminName = scanner.next();
//							
								try {
									System.out.println("Enter Mobile :");
									adminMobile = scanner.nextLong();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								System.out.println("Enter Email :");
								adminEmail = scanner.next();
//								
								System.out.println("Enter Password :");
								adminPassword = scanner.next();
//								

								adminBean = new AdminInfoBean();

								adminBean.setAdminId(adminId);
								adminBean.setAdminName(adminName);
								adminBean.setMobileNum(adminMobile);
								adminBean.setEmail(adminEmail);
								adminBean.setPassword(adminPassword);
								try {
									boolean check = service.adminReg(adminBean);
									if (check) {
										System.out.println("***********Register Syccessfully***********");
									} else {
										System.out.println("Email already exist in the Database");
									}

								} catch (UserExceptions e) {
									System.err.println(e.getMessage());
								}
								break;
							case 2:
								System.out.println("Enter Email :");
								adminEmail = scanner.next();
								System.out.println("Enter Password :");
								adminPassword = scanner.next();
								try {
									adminBean = service.adminLogin(adminEmail, adminPassword);
									System.out.println("You have login successfully");

									do {
										try {
											System.out.println("*******Welcome To Login Page*******");
											System.out.println("Press 1 to Edit Your Profile ");
											System.out.println("Press 2 to Get the all User Details");
											System.out.println("Press 3 for Create User");
											System.out.println("Press 4 to see all the User Requests");
											System.out.println("Press 5 to check your details");
											System.out.println("To Logout Press 6");
											System.out.println("***********************************");

											int choice1 = scanner.nextInt();
											switch (choice1) {
											case 1:
												try {
													System.out.println("Select which field to change");
													System.out.println("1.Name");
													System.out.println("2.Email");
													System.out.println("3.Mobilenum");
													System.out.println("4.Password");

													int choice3 = scanner.nextInt();
													switch (choice3) {
													case 1:
														System.out.println("Please enter name");
														adminName = scanner.next();

														System.out.println("Enter Password :");
														adminPassword = scanner.next();

												
														try {
															adminBean.setPassword(adminPassword);
															AdminInfoBean admin =new AdminInfoBean();	
															admin.setAdminName(adminName);
															
															
															adminBean = service.editAdminProfile(adminBean,admin);
															System.out.println(
																	"*******Profile Edited Successfully*******");

														} catch (UserExceptions e) {
															System.err.println(e.getMessage());
														}

														break;
													case 2:
														System.out.println("Please enter Email");
														adminEmail = scanner.next();

														try {
															adminBean.setPassword(adminPassword);
															AdminInfoBean admin =new AdminInfoBean();
															admin.setEmail(adminName);
															service.editAdminProfile(adminBean,admin);
															System.out.println(
																	"*******Profile Edited Successfully*******");

														} catch (UserExceptions e) {
															System.err.println(e.getMessage());
														}
														break;
													case 3:
														System.out.println("Please enter Password");
														adminPassword = scanner.next();

														try {

															adminBean.setPassword(adminPassword);
															AdminInfoBean admin =new AdminInfoBean();
															admin.setPassword(adminPassword);
															service.editAdminProfile(adminBean,admin);
															System.out.println(
																	"*******Profile Edited Successfully*******");

														} catch (UserExceptions e) {
															System.err.println(e.getMessage());
														}

														break;
													case 4:
														try {
															System.out.println("Please enter mobilenum");
															adminMobile = scanner.nextLong();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}

														try {
															adminBean.setPassword(adminPassword);
															AdminInfoBean admin =new AdminInfoBean();
															admin.setMobileNum(adminMobile);
															service.editAdminProfile(adminBean,admin);
															System.out.println(
																	"*******Profile Edited Successfully*******");
														} catch (UserExceptions e) {
															System.err.println(e.getMessage());
														}
														break;
													default:
														System.err.println("Invalid Choice!!Enter choice between 1-5");
														break;
													}
												} catch (InputMismatchException e) {
													System.err.println(
															"Incorrect entry. Please enter above options only");
													scanner.nextLine();
												}
												break;
											case 2:
												try {
													List<UserInfoBean> details = service.getUserDetails();
													System.out.println(
															"***********Welcome to User Details Section************");
													System.out.println(
															String.format("%-10s %-10s %-15s  %-15s  %-15s  %-15s %s",
																	"UserId", "UserName", "MailId", "Password",
																	"PhoneNumber", "AcctNum", "Balance"));
													for (UserInfoBean user : details) {
														System.out.println(String.format(
																"%-10s %-10s %-13s  %-15s  %-15s  %-14s  %s",
																user.getUserId(), user.getName(), user.getEmail(),
																user.getPassword(), user.getMobileNum(),
																user.getAcctNum(), user.getBalance()));
													}
												} catch (UserExceptions e) {
													System.err.println("No Users are available");
												}

												break;
											case 3:
												try {
													System.out.println("Enter ID :");
													userId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												System.out.println("Enter Name :");
												userName = scanner.next();

												try {
													System.out.println("Enter Mobile :");
													userMobile = scanner.nextLong();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												System.out.println("Enter Email :");
												userEmail = scanner.next();

												System.out.println("Enter Password :");
												userPassword = scanner.next();

												try {
													System.out.println("Enter Account Number :");
													userAcctNum = scanner.nextLong();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {
													System.out.println("Enter Your Balance :");
													balance = scanner.nextDouble();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												userBean = new UserInfoBean();

												userBean.setUserId(userId);
												userBean.setName(userName);
												userBean.setMobileNum(userMobile);
												userBean.setEmail(userEmail);
												userBean.setPassword(userPassword);
												userBean.setAcctNum(userAcctNum);
												userBean.setBalance(balance);
												try {
													boolean check1 = service.addUser(userBean);
													if (check1) {

														System.out.println(
																"***********User Added Syccessfully***********");
													} else {
														System.out.println("Email already exist");
													}
												} catch (UserExceptions e) {
													System.err.println(e.getMessage());
												}
												break;
											case 4:
												try {
													System.out.println("Requests of All User's are :");
													System.out.println(
															"------------------------------------------------------------------------");
													System.out.println("CheckBookReqId");

													List<RequestInfoBean> requestInfos = service.reqById();
													for (RequestInfoBean info1 : requestInfos) {
														System.out.println(info1.getCheckBookReq());
													}

												} catch (UserExceptions e) {
													System.err.println("No CheckBook Request's Occured");
												}

												break;

											case 5:
												try {
													System.out.println("Please enter Id");
													adminId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}
												try {
													AdminInfoBean bean = service.getYourDetails(adminId);
													System.out.println("******Welcome to Your Details Section****");
													System.out.println("AdminId---------->" + bean.getAdminId());
													System.out.println("Name------------->" + bean.getAdminName());
													System.out.println("EmailId---------->" + bean.getEmail());
													System.out.println("Password--------->" + bean.getPassword());
													System.out.println("MobileNum-------->" + bean.getMobileNum());

												} catch (UserExceptions e) {
													System.err.println(e.getMessage());
												}

												break;
											case 6:
												doReg();
											default:
												System.err.println("Invalid Choice!!Enter choice between 1-6");
												break;
											}
										} catch (InputMismatchException ex) {
											System.err.println("Incorrect entry. Please enter above options only");
											scanner.nextLine();
										}
									} while (true);
								} catch (UserExceptions e) {
									System.err.println(e.getMessage());
								}
								break;
							case 3:
								doReg();
							default:
								System.err.println("Invalid Choice!!Enter choice between 1-3");
								break;
							}
						} catch (InputMismatchException ex) {
							System.err.println("Incorrect entry. Please enter above options only");
							scanner.nextLine();
						}
					} while (true);
				case 2:
					UserService userService = UserFactory.getUserServiceImplDaoInstance();
					do {
						try {
							System.out.println("***********************************");
							System.out.println("You Want to Register Press 1");
							System.out.println("You Want to Login Press 2");
							System.out.println("press 3 to exit");
							System.out.println("***********************************");
							int choice = scanner.nextInt();
							switch (choice) {
							case 1:
								try {
									System.out.println("Enter ID :");
									userId = scanner.nextInt();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								System.out.println("Enter Name :");
								userName = scanner.next();

								try {
									System.out.println("Enter Mobile :");
									userMobile = scanner.nextLong();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								System.out.println("Enter Email :");
								userEmail = scanner.next();

								System.out.println("Enter Password :");
								userPassword = scanner.next();

								try {
									System.out.println("Enter Account Number :");
									userAcctNum = scanner.nextLong();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								try {
									System.out.println("Enter Your Balance :");
									balance = scanner.nextDouble();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								userBean = new UserInfoBean();

								userBean.setUserId(userId);
								userBean.setName(userName);
								userBean.setMobileNum(userMobile);
								userBean.setEmail(userEmail);
								userBean.setPassword(userPassword);
								userBean.setAcctNum(userAcctNum);
								userBean.setBalance(balance);

								try {
									boolean check = userService.userReg(userBean);
									if (check) {
										System.out.println("***********Register Syccessfully***********");
									} else {
										System.out.println("Email already exist");
									}
								} catch (UserExceptions e) {
									System.err.println(e.getMessage());
								}
								break;
							case 2:
								System.out.println("Enter Email :");
								userEmail = scanner.next();
								System.out.println("Enter Password :");
								userPassword = scanner.next();

								try {
									userBean = userService.userLogin(userEmail, userPassword);
									System.out.println("You have login successfully");
									do {
										try {

											System.out.println("***********************************");
											System.out.println("Press 1 for Edit Profile Page");
											System.out.println("Press 2 to send check book request");
											System.out.println("Press 3 to View Your Profile");
											System.out.println("Press 4 to Transfer Money");
											System.out.println("Press 5 for Logout");
											System.out.println("***********************************");

											int choice1 = scanner.nextInt();
											switch (choice1) {
											case 1:
												try {
													System.out.println("***********************************");
													System.out.println("Select which option to change");
													System.out.println("1.Name");
													System.out.println("2.Email");
													System.out.println("3.Mobilenum");
													System.out.println("4.Password");

													int choice2 = scanner.nextInt();
													switch (choice2) {
													case 1:
														System.out.println("Please enter name");
														userName = scanner.next();

														try {
															userBean = userService.editProfile(userBean);
															userBean.setName(userName);
															System.out.println(
																	"*******Profile Edited Successfully*******");

														} catch (Exception e) {
															System.err.println("Value Already Exist");
														}
														break;
													case 2:
														System.out.println("Please enter Email");
														userEmail = scanner.next();

														try {
															userBean.setEmail(userEmail);
															userService.editProfile(userBean);
															System.out.println(
																	"*******Profile Edited Successfully*******");

														} catch (UserExceptions e) {
															System.err.println(e.getMessage());
														}
														break;
													case 3:
														System.out.println("Please enter Password");
														userPassword = scanner.next();

														try {
															userBean.setPassword(userPassword);
															userService.editProfile(userBean);
															System.out.println(
																	"*******Profile Edited Successfully*******");

														} catch (UserExceptions e) {
															System.err.println(e.getMessage());
														}
														break;
													case 4:
														try {
															System.out.println("Please enter mobilenum");
															userMobile = scanner.nextLong();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}

														try {
															userBean.setMobileNum(userMobile);
															userService.editProfile(userBean);
															System.out.println(
																	"*******Profile Edited Successfully*******");
														} catch (UserExceptions e) {
															System.err.println(e.getMessage());
														}
														break;
													default:
														System.err.println("Invalid Choice!!Enter choice between 1-4");
														break;
													}
												} catch (InputMismatchException ex) {
													System.out.println(
															"Incorrect entry. Please enter above options only");
													scanner.nextLine();
												}
												break;
											case 2:
												try {
													System.out.println("Please enter your Id To Send Request");
													userReqId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {
													RequestInfoBean req = new RequestInfoBean();
													req.setCheckBookReq(userReqId);
													@SuppressWarnings("unused")
													boolean req1 = userService.checkBookReq(req);
													System.out
															.println("*******Request hasbeen sent Successfully*******");
													System.out.println(
															"*******Request should be Processed with in a week*******");
												} catch (Exception e) {
													System.err.println("Request Already Sent/Check Your UserId and Try Again!!!");
												}
												break;
											case 3:
												try {
													System.out.println("Please enter UserId");
													userId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {
													UserInfoBean bean = userService.getYourDetails(userId);
													System.out.println("******Welcome to Your Details Section****");
													System.out.println("UserId-------------->" + bean.getUserId());
													System.out.println("Name---------------->" + bean.getName());
													System.out.println("EmailId------------->" + bean.getEmail());
													System.out.println("Password------------>" + bean.getPassword());
													System.out.println("MobileNum----------->" + bean.getMobileNum());
													System.out.println("Account Number------>" + bean.getAcctNum());
													System.out.println("Current Balance----->" + bean.getBalance());
												} catch (UserExceptions e) {
													System.err.println(e.getMessage());
												}
												break;

											case 4:
												try {
													System.out.println("Enter ID :");
													userId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {
													System.out.println("Enter Account Number to transfer money :");
													userAcctNum = scanner.nextLong();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {
													System.out.println("Enter Amount to Transfer");
													balance = scanner.nextDouble();

												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												userBean = new UserInfoBean();

												userBean.setUserId(userId);

												UserInfoBean userBean1 = new UserInfoBean();
												userBean1.setAcctNum(userAcctNum);

												try {
													if (balance != 0) {
														userBean.setBalance(balance);
													} else {
														throw new UserExceptions("Amount Should be Greaterthan Zero");
													}
													boolean isValid = userService.transferMoney(userBean, userBean1);

													if (isValid) {
														System.out.println("Transaction Successfull");
													} else {
														System.err.println("Transaction Failed");
													}
												} catch (UserExceptions e) {
													System.err.println(e.getMessage());
												}
												break;
											case 5:
												doReg();
											default:
												System.err.println("Invalid Choice!!Enter choice between 1-3");
												break;
											}
										} catch (InputMismatchException ex) {
											System.err.println("Incorrect entry. Please enter above options only");
											scanner.nextLine();
										}
									} while (true);
								} catch (UserExceptions e) {
									System.err.println(e.getMessage());
								}
								break;
							case 3:
								doReg();
							default:
								System.err.println("Invalid Choice!!Enter choice between 1-3");
								break;
							}
						} catch (InputMismatchException e) {
							System.err.println("Incorrect entry. Please enter above options only");
							scanner.nextLine();
						}
					} while (true);
				default:
					System.err.println("Invalid Choice!!Enter choice between 1-2");
					break;
				}

			} catch (InputMismatchException e) {
				System.err.println("Incorrect entry. Please enter above options only");
				scanner.nextLine();
			}
		} while (true);
	}
}