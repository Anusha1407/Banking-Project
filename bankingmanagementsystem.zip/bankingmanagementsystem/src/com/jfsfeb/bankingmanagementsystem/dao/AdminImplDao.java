package com.jfsfeb.bankingmanagementsystem.dao;

import java.util.List;

import com.jfsfeb.bankingmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.UserInfoBean;
import com.jfsfeb.bankingmanagementsystem.exception.UserExceptions;
import com.jfsfeb.bankingmanagementsystem.repository.BankingDb;

public class AdminImplDao implements AdminDao {

	@Override
	public boolean adminReg(AdminInfoBean admin) {
		for (AdminInfoBean info : BankingDb.ADMIN) {
			if (info.getEmail().equals(admin.getEmail())) {
				return false;
			}
		}
		BankingDb.ADMIN.add(admin);
		return true;
	}

	@Override
	public AdminInfoBean adminLogin(String email, String password) {
		for (AdminInfoBean info : BankingDb.ADMIN) {
			if (email.equals(info.getEmail()) && password.equals(info.getPassword())) {
				return info;
			}
		}
		throw new UserExceptions("Invalid credentials");
	}

	@Override
	public AdminInfoBean editAdminProfile(AdminInfoBean admin, AdminInfoBean admin1) {
		for(AdminInfoBean info :BankingDb.ADMIN) {
			if(info.getPassword().equals(admin.getPassword())) {
				if(info.getAdminName().equals(admin.getAdminName())) {
					throw new UserExceptions("Value Already Exist");
				}
				throw new UserExceptions("Value Already Exist");
			}
		}

		return admin;
	}

	@Override
	public boolean addUser(UserInfoBean user) {
		for (UserInfoBean info : BankingDb.USER) {
			if (info.getEmail().equals(user.getEmail())) {
				return false;
			}
		}
		BankingDb.USER.add(user);
		return true;
	}

	@Override
	public List<UserInfoBean> getUserDetails() {
		for (UserInfoBean info : BankingDb.USER) {
			if (info != null)
				return BankingDb.USER;
		}
		return null;
	}

	@Override
	public List<RequestInfoBean> reqById() {
		for (RequestInfoBean info : BankingDb.REQU) {
			if (info != null)
				return BankingDb.REQU;
		}
		return null;
	}

	@Override
	public AdminInfoBean getYourDetails(int Id) {
		for (AdminInfoBean info : BankingDb.ADMIN) {
			if (info.getAdminId() == Id) {
				return info;
			}
		}
		throw new UserExceptions("Incorrect Email Id");
	}
}
