package com.jfsfeb.bankingmanagementsystem.dao;


import com.jfsfeb.bankingmanagementsystem.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.UserInfoBean;

public interface UserDao {

	public boolean userReg(UserInfoBean user);

	public UserInfoBean userLogin(String email, String pass);

	public UserInfoBean editProfile(UserInfoBean user);

	public boolean checkBookReq(RequestInfoBean requ);

	public UserInfoBean getYourDetails(int Id);

	public boolean transferMoney(UserInfoBean toDetails,UserInfoBean sendDetails);

}
