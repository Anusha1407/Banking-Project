package com.jfsfeb.bankingmanagementsystem.dao;

import com.jfsfeb.bankingmanagementsystem.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.UserInfoBean;
import com.jfsfeb.bankingmanagementsystem.exception.UserExceptions;
import com.jfsfeb.bankingmanagementsystem.repository.BankingDb;

public class UserImplDao implements UserDao {

	@Override
	public boolean userReg(UserInfoBean user) {
		for (UserInfoBean info : BankingDb.USER) {
			if (info.getEmail().equals(user.getEmail())) {
				return false;
			}
		}
		BankingDb.USER.add(user);
		return true;
	}

	@Override
	public UserInfoBean userLogin(String email, String password) {
		for (UserInfoBean info : BankingDb.USER) {
			if (email.equals(info.getEmail()) && password.equals(info.getPassword())) {
				return info;
			}
		}
		throw new UserExceptions("Invalid credentials");
	}

	@Override
	public UserInfoBean editProfile(UserInfoBean user) {
		return user;
	}

	@Override
	public boolean checkBookReq(RequestInfoBean requ) {
		for (RequestInfoBean info : BankingDb.REQU) {
			if (info.getCheckBookReq() == requ.getCheckBookReq()) {
				throw new UserExceptions("Request Already Sent/Check Your UserId and Try Again!!!");
			}
		}
		BankingDb.REQU.add(requ);
		return true;
	}

	@Override
	public UserInfoBean getYourDetails(int Id) {
		for (UserInfoBean info : BankingDb.USER) {
			if (info.getUserId() == Id) {
				return info;
			}
		}
		throw new UserExceptions("Incorrect Email Id");
	}

	@Override
	public boolean transferMoney(UserInfoBean toDetails, UserInfoBean sendDetails) {
		boolean isValid = false;

		for (UserInfoBean info : BankingDb.USER) {
			if (info.getAcctNum() == sendDetails.getAcctNum()) {
				double changedBal = info.getBalance() + toDetails.getBalance();
				sendDetails.setBalance(changedBal);
				isValid = true;
			}
		}

		if (isValid) {
			for (UserInfoBean info : BankingDb.USER) {
				if (info.getUserId() == toDetails.getUserId() && info.getBalance() >= toDetails.getBalance()) {
					double changedBal = info.getBalance() - toDetails.getBalance();
					info.setBalance(changedBal);
					return true;
				}
			}
		}
		throw new UserExceptions("Insufficient Amount/Check Your Id/Check the Account Number");
	}

}