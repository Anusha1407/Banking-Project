package com.jfsfeb.bankingmanagementsystem.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.ToString;


@Data
@SuppressWarnings("serial")
public class AdminInfoBean implements Serializable {
	private int adminId;
	private String adminName;
	private long mobileNum;
	private String email;
	@ToString.Exclude
	private String password;

}
