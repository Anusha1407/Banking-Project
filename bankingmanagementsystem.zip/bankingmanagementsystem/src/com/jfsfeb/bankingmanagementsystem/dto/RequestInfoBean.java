package com.jfsfeb.bankingmanagementsystem.dto;

import java.io.Serializable;

import lombok.Data;

@Data
@SuppressWarnings("serial")
public class RequestInfoBean implements Serializable {
	private int redId;
	private int acctReq;
	private int checkBookReq;
	private UserInfoBean user;
}