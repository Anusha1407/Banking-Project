package com.jfsfeb.bankingmanagementsystem.dto;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;


@Data
@SuppressWarnings("serial")
public class TransactionInfoBean implements Serializable {
	private int transId;
	private Date dot;
	private double balance;
	private double credit;
	private double debit;
	private UserInfoBean user;

}
