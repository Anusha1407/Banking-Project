package com.jfsfeb.bankingmanagementsystem.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.ToString;


@Data
@SuppressWarnings("serial")
public class UserInfoBean implements Serializable {
	private int userId;
	private String name;
	private long mobileNum;
	private String email;
	private double balance;
	private long acctNum;
	@ToString.Exclude
	private String password;

}
