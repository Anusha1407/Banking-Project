package com.jfsfeb.bankingmanagementsystem.exception;

@SuppressWarnings("serial")
public class UserExceptions extends RuntimeException {

	public UserExceptions(String msg) {
		super(msg);
	}
}
