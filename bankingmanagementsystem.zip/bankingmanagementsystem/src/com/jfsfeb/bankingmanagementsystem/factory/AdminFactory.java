package com.jfsfeb.bankingmanagementsystem.factory;

import com.jfsfeb.bankingmanagementsystem.dao.AdminDao;
import com.jfsfeb.bankingmanagementsystem.dao.AdminImplDao;
import com.jfsfeb.bankingmanagementsystem.service.AdminService;
import com.jfsfeb.bankingmanagementsystem.service.AdminServiceImpl;
import com.jfsfeb.bankingmanagementsystem.validitation.BankingValidation;
import com.jfsfeb.bankingmanagementsystem.validitation.Validation;

public class AdminFactory {

	private AdminFactory() {

	}

	public static AdminDao getAdminImplDaoInstance() {
		AdminDao adminDao = new AdminImplDao();
		return adminDao;
	}

	public static AdminService getAdminServiceImplDaoInstance() {
		AdminService adminService = new AdminServiceImpl();
		return adminService;
	}

	public static BankingValidation getValidationInstance() {
		BankingValidation validation = new Validation();
		return validation;
	}
}
