package com.jfsfeb.bankingmanagementsystem.factory;

import com.jfsfeb.bankingmanagementsystem.dao.UserDao;
import com.jfsfeb.bankingmanagementsystem.dao.UserImplDao;
import com.jfsfeb.bankingmanagementsystem.service.UserService;
import com.jfsfeb.bankingmanagementsystem.service.UserServiceImpl;
import com.jfsfeb.bankingmanagementsystem.validitation.BankingValidation;
import com.jfsfeb.bankingmanagementsystem.validitation.Validation;

public class UserFactory {
	private UserFactory() {

	}

	public static UserDao getUserImplDaoInstance() {
		UserDao userDao = new UserImplDao();
		return userDao;
	}

	public static UserService getUserServiceImplDaoInstance() {
		UserService userService = new UserServiceImpl();
		return userService;
	}

	public static BankingValidation getValidationInstance() {
		BankingValidation validation = new Validation();
		return validation;
	}
}
