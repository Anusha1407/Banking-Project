package com.jfsfeb.bankingmanagementsystem.repository;

import java.util.ArrayList;
import java.util.List;

import com.jfsfeb.bankingmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.TransactionInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.UserInfoBean;

public class BankingDb {

	public static final List<UserInfoBean> USER = new ArrayList<UserInfoBean>();
	public static final List<AdminInfoBean> ADMIN = new ArrayList<AdminInfoBean>();
	public static final List<TransactionInfoBean> TRANS = new ArrayList<TransactionInfoBean>();
	public static final List<RequestInfoBean> REQU = new ArrayList<RequestInfoBean>();

	public static void addToDb()
	{
		AdminInfoBean admin = new AdminInfoBean();
		admin.setAdminId(100000);
		admin.setAdminName("Anuu");
		admin.setEmail("anusha@gmail.com");
		admin.setMobileNum(9876543211l);
		admin.setPassword("Sreerama@1");
		ADMIN.add(admin);
		
		UserInfoBean user = new UserInfoBean();
		user.setAcctNum(98765432112345l);
		user.setBalance(9000);
		user.setEmail("anuveeranki@gmail.com");
		user.setMobileNum(8688442205l);
		user.setName("anuveeranki");
		user.setPassword("Sreerama@1");
		user.setUserId(100001);
		USER.add(user);
		
		UserInfoBean user1 = new UserInfoBean();
		user1.setAcctNum(98768765432345l);
		user1.setBalance(9000);
		user1.setEmail("divyaveeranki@gmail.com");
		user1.setMobileNum(8688442205l);
		user1.setName("anuveeranki");
		user1.setPassword("Sreerama@1");
		user1.setUserId(100002);
		USER.add(user1);
		
	}
}
