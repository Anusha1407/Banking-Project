package com.jfsfeb.bankingmanagementsystem.service;

import java.util.List;

import com.jfsfeb.bankingmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.UserInfoBean;

public interface AdminService {
	public boolean adminReg(AdminInfoBean bean);

	public AdminInfoBean adminLogin(String email, String password);

	public AdminInfoBean editAdminProfile(AdminInfoBean admin,AdminInfoBean admin1);

	public boolean addUser(UserInfoBean user);

	public List<RequestInfoBean> reqById();

	public AdminInfoBean getYourDetails(int Id);

	public List<UserInfoBean> getUserDetails();

}
