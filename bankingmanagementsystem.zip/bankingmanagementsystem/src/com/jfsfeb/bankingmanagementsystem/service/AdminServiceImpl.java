package com.jfsfeb.bankingmanagementsystem.service;

import java.util.List;

import com.jfsfeb.bankingmanagementsystem.dao.AdminDao;
import com.jfsfeb.bankingmanagementsystem.dto.AdminInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.UserInfoBean;
import com.jfsfeb.bankingmanagementsystem.factory.AdminFactory;
import com.jfsfeb.bankingmanagementsystem.validitation.BankingValidation;

public class AdminServiceImpl implements AdminService {
	AdminDao dao = AdminFactory.getAdminImplDaoInstance();
	BankingValidation validation = AdminFactory.getValidationInstance();

	@Override
	public boolean adminReg(AdminInfoBean bean) {
		if (validation.validatedId(bean.getAdminId())) {
			if (validation.validatedName(bean.getAdminName())) {
				if (validation.validatedEmail(bean.getEmail())) {
					if (validation.validatedMobile(bean.getMobileNum())) {
						if (validation.validatedPassword(bean.getPassword())) {
							return dao.adminReg(bean);
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public AdminInfoBean adminLogin(String email, String password) {
		if (validation.validatedEmail(email)) {
			if (validation.validatedPassword(password)) {
				return dao.adminLogin(email, password);
			}
		}
		return null;
	}

	@Override
	public AdminInfoBean editAdminProfile(AdminInfoBean bean,AdminInfoBean bean1) {
		if (validation.validatedName(bean.getAdminName()) || validation.validatedEmail(bean.getEmail())
				|| validation.validatedMobile(bean.getMobileNum())
				|| validation.validatedPassword(bean.getPassword())) {
			return dao.editAdminProfile(bean,bean1);
		}
		return null;
	}

	@Override
	public boolean addUser(UserInfoBean user) {
		if (validation.validatedId(user.getUserId())) {
			if (validation.validatedName(user.getName())) {
				if (validation.validatedEmail(user.getEmail())) {
					if (validation.validatedMobile(user.getMobileNum())) {
						if (validation.validatedPassword(user.getPassword())) {
							if (validation.validatedAcctNo(user.getAcctNum())) {
								if (validation.validatedBalance(user.getBalance())) {
									return dao.addUser(user);
								}
							}
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public List<UserInfoBean> getUserDetails() {
		return dao.getUserDetails();
	}

	@Override
	public List<RequestInfoBean> reqById() {
		return dao.reqById();
	}

	@Override
	public AdminInfoBean getYourDetails(int Id) {
		if (validation.validatedId(Id)) {
			return dao.getYourDetails(Id);
		}
		return null;
	}

}
