package com.jfsfeb.bankingmanagementsystem.service;


import com.jfsfeb.bankingmanagementsystem.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.UserInfoBean;

public interface UserService {
	public boolean userReg(UserInfoBean user);

	public UserInfoBean userLogin(String user, String password);

	public UserInfoBean editProfile(UserInfoBean user);

	public boolean checkBookReq(RequestInfoBean requ);

	public UserInfoBean getYourDetails(int Id);

	public boolean transferMoney(UserInfoBean toDetails,UserInfoBean sendDetails);
}
