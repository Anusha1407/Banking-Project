package com.jfsfeb.bankingmanagementsystem.service;

import com.jfsfeb.bankingmanagementsystem.dao.UserDao;
import com.jfsfeb.bankingmanagementsystem.dao.UserImplDao;
import com.jfsfeb.bankingmanagementsystem.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystem.dto.UserInfoBean;
import com.jfsfeb.bankingmanagementsystem.exception.UserExceptions;
import com.jfsfeb.bankingmanagementsystem.factory.AdminFactory;
import com.jfsfeb.bankingmanagementsystem.validitation.BankingValidation;

public class UserServiceImpl implements UserService {
	UserDao dao = new UserImplDao();
	BankingValidation validation = AdminFactory.getValidationInstance();

	@Override
	public boolean userReg(UserInfoBean user) {
		if (validation.validatedId(user.getUserId())) {
			if (validation.validatedName(user.getName())) {
				if (validation.validatedEmail(user.getEmail())) {
					if (validation.validatedMobile(user.getMobileNum())) {
						if (validation.validatedPassword(user.getPassword())) {
							if (validation.validatedAcctNo(user.getAcctNum())) {
								if (validation.validatedBalance(user.getBalance())) {
									return dao.userReg(user);
								}
							}
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public UserInfoBean userLogin(String user, String password) {
		if (validation.validatedEmail(user)) {
			if (validation.validatedPassword(password)) {
				return dao.userLogin(user, password);
			} else {
				throw new UserExceptions("Enter Proper EmailId");
			}
		}
		throw new UserExceptions(
				"Password should contain atleast 6 characters ,one uppercase,one lowercase,one number and one special symbol(@#$%?!)");
	}

	@Override
	public UserInfoBean editProfile(UserInfoBean user) {
		if (validation.validatedName(user.getName()) || validation.validatedEmail(user.getEmail())
				|| validation.validatedMobile(user.getMobileNum())
				|| validation.validatedPassword(user.getPassword())) {
			return dao.editProfile(user);
		}
		return null;
	}

	@Override
	public boolean checkBookReq(RequestInfoBean req) {
		if (validation.validatedId(req.getCheckBookReq())) {
			return dao.checkBookReq(req);
		}
		return false;
	}

	@Override
	public UserInfoBean getYourDetails(int Id) {
		if (validation.validatedId(Id)) {
			return dao.getYourDetails(Id);
		}
		return null;
	}

	@Override
	public boolean transferMoney(UserInfoBean toDetails, UserInfoBean sendDetails) {

		if (validation.validatedId(toDetails.getUserId())) {
			if (validation.validatedAcctNo(sendDetails.getAcctNum())) {
				if (validation.validatedBalance(toDetails.getBalance())) {
					return dao.transferMoney(toDetails, sendDetails);
				}
			}
		}
		return false;
	}

}
