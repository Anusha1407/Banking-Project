package com.jfsfeb.bankingmanagementsystem.validitation;

public interface BankingValidation {
	public boolean validatedId(int id);

	public boolean validatedName(String name);

	public boolean validatedMobile(long regMobile);

	public boolean validatedAcctNo(long Acctnum);

	public boolean validatedBalance(double balance);

	public boolean validatedEmail(String email);

	public boolean validatedPassword(String password);
}
