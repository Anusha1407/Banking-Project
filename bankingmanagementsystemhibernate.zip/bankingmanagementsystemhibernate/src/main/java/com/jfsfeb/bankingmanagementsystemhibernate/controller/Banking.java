package com.jfsfeb.bankingmanagementsystemhibernate.controller;

public class Banking {
	public static void main(String[] args) {
		App.doReg();
	}
}
