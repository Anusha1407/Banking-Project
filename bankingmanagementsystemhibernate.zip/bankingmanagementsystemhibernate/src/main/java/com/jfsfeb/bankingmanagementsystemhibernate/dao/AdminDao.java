package com.jfsfeb.bankingmanagementsystemhibernate.dao;

import java.util.List;

import com.jfsfeb.bankingmanagementsystemhibernate.dto.InfoBean;
import com.jfsfeb.bankingmanagementsystemhibernate.dto.RequestInfoBean;


public interface AdminDao {
	public boolean adminReg(InfoBean bean);

	public InfoBean adminLogin(String email, String password);

	public InfoBean editAdminProfile(InfoBean admin);

	public boolean addUser(InfoBean user);

	public List<RequestInfoBean> reqById();

	public InfoBean getYourDetails(int Id);

	public List<InfoBean> getUserDetails();

}
