package com.jfsfeb.bankingmanagementsystemhibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.jfsfeb.bankingmanagementsystemhibernate.dto.InfoBean;
import com.jfsfeb.bankingmanagementsystemhibernate.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystemhibernate.exception.UserExceptions;

public class AdminImplDao implements AdminDao {

	EntityManagerFactory emf = null;
	EntityManager manager = null;
	EntityTransaction trans = null;

	@Override
	public boolean adminReg(InfoBean bean) {
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();
			manager.persist(bean);
			trans.commit();
			return true;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			trans.rollback();
			return false;
		} finally {
			manager.close();
			emf.close();
		}
	}

	@Override
	public InfoBean adminLogin(String email, String password) {
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();

			String jpql = "select u from InfoBean u where u.email=:email and u.password=:password and role='admin'";
			TypedQuery<InfoBean> query = manager.createQuery(jpql, InfoBean.class);
			query.setParameter("email", email);
			query.setParameter("password", password);
			InfoBean bean = query.getSingleResult();
			return bean;
		} catch (Exception e) {
			System.err.println("Invald Credentials");
			trans.rollback();
			return null;
		} finally {
			manager.close();
			emf.close();
		}

	}

	@Override
	public InfoBean editAdminProfile(InfoBean admin) {

		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();

			String jpql = "update InfoBean e set e.name=:na, e.email=:em, e.password=:pass, e.mobileNum=:num where e.userId=:id";

			Query query = manager.createQuery(jpql);

			query.setParameter("na", admin.getName());
			query.setParameter("em", admin.getEmail());
			query.setParameter("pass", admin.getPassword());
			query.setParameter("num", admin.getMobileNum());
			query.setParameter("id", admin.getUserId());

			query.executeUpdate();
			trans.commit();
		} catch (Exception e) {
			e.printStackTrace();
			trans.rollback();
		} finally {
			manager.close();
			emf.close();
		}
		return admin;
	}

	@Override
	public boolean addUser(InfoBean user) {
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();
			manager.persist(user);
			trans.commit();
			return true;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			trans.rollback();
			return false;
		} finally {
			manager.close();
			emf.close();
		}
	}

	@Override
	public List<RequestInfoBean> reqById() {
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();

			String jpql = "select r from RequestInfoBean r";
			TypedQuery<RequestInfoBean> query = manager.createQuery(jpql, RequestInfoBean.class);
			List<RequestInfoBean> recordList = query.getResultList();

			if (recordList == null) {
				throw new UserExceptions("No Request's Available");
			} else {
				return recordList;
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
			trans.rollback();
			return null;
		} finally {
			manager.close();
			emf.close();
		}
	}

	@Override
	public InfoBean getYourDetails(int Id) {
		emf = Persistence.createEntityManagerFactory("TestPersistence");
		manager = emf.createEntityManager();

		String jpql = "select e from InfoBean e where e.userId=:id";
		Query query = manager.createQuery(jpql);
		query.setParameter("id", Id);
		InfoBean emp = (InfoBean) query.getSingleResult();

		manager.close();
		emf.close();
		return emp;

	}

	@Override
	public List<InfoBean> getUserDetails() {
		emf = Persistence.createEntityManagerFactory("TestPersistence");
		manager = emf.createEntityManager();

		String jpql = "select u from InfoBean u where role='admin'";
		TypedQuery<InfoBean> query = manager.createQuery(jpql, InfoBean.class);
		List<InfoBean> recordList = query.getResultList();

		manager.close();
		emf.close();
		return recordList;

	}

}
