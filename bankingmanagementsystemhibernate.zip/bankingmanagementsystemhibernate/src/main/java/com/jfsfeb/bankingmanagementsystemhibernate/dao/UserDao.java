package com.jfsfeb.bankingmanagementsystemhibernate.dao;


import com.jfsfeb.bankingmanagementsystemhibernate.dto.InfoBean;
import com.jfsfeb.bankingmanagementsystemhibernate.dto.RequestInfoBean;

public interface UserDao {

	public boolean userReg(InfoBean user);

	public InfoBean userLogin(String email, String pass);

	public InfoBean editProfile(InfoBean user);

	public RequestInfoBean checkBookReq(RequestInfoBean requ);

	public InfoBean getYourDetails(int Id);

	public boolean transferMoney(InfoBean toDetails,InfoBean sendDetails);

}
