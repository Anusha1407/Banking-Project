package com.jfsfeb.bankingmanagementsystemhibernate.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.jfsfeb.bankingmanagementsystemhibernate.dto.InfoBean;
import com.jfsfeb.bankingmanagementsystemhibernate.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystemhibernate.exception.UserExceptions;

public class UserImplDao implements UserDao {

	EntityManagerFactory emf = null;
	EntityManager manager = null;
	EntityTransaction trans = null;

	@Override
	public boolean userReg(InfoBean user) {
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();
			manager.persist(user);
			trans.commit();
			return true;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			trans.rollback();
			return false;
		} finally {
			manager.close();
			emf.close();
		}
	}

	@Override
	public InfoBean userLogin(String email, String pass) {
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();

			String jpql = "select u from InfoBean u where u.email=:email and u.password=:password and role='user'";
			TypedQuery<InfoBean> query = manager.createQuery(jpql, InfoBean.class);
			query.setParameter("email", email);
			query.setParameter("password", pass);
			InfoBean bean = query.getSingleResult();
			return bean;
		} catch (Exception e) {
			System.err.println("Invalid Credentials");
			trans.rollback();
			return null;
		} finally {
			manager.close();
			emf.close();
		}
	}

	@Override
	public InfoBean editProfile(InfoBean user) {
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();

			String jpql = "update InfoBean e set e.name=:na, e.email=:em, e.password=:pass, e.mobileNum=:num where e.userId=:id";

			Query query = manager.createQuery(jpql);

			query.setParameter("na", user.getName());
			query.setParameter("em", user.getEmail());
			query.setParameter("pass", user.getPassword());
			query.setParameter("num", user.getMobileNum());
			query.setParameter("id", user.getUserId());

			query.executeUpdate();
			trans.commit();
		} catch (Exception e) {
			trans.rollback();
			throw new UserExceptions("Check Your Entered Id and do again!!");
		} finally {
			manager.close();
			emf.close();
		}
		return user;
	}

	@Override
	public RequestInfoBean checkBookReq(RequestInfoBean requ) {
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();

			String jpql = "update RequestInfoBean r set r.checkBookReq=:check where r.reqId=:id";

			Query query = manager.createQuery(jpql);

			query.setParameter("check", requ.getCheckBookReq());
			query.setParameter("id", requ.getReqId());

			query.executeUpdate();
			trans.commit();
		} catch (Exception e) {
			trans.rollback();
			throw new UserExceptions(e.getMessage());
		} finally {
			manager.close();
			emf.close();
		}
		return requ;
	}

	@Override
	public InfoBean getYourDetails(int Id) {
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();

			String jpql = "select e from InfoBean e where e.userId=:id";
			Query query = manager.createQuery(jpql);
			query.setParameter("id", Id);
			InfoBean emp = (InfoBean) query.getSingleResult();
			return emp;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			trans.rollback();
			return null;
		} finally {
			manager.close();
			emf.close();
		}
	}

	@Override
	public boolean transferMoney(InfoBean toDetails, InfoBean sendDetails) {
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();

			String jpql = "update InfoBean e set e.balance=:bal where e.userId=:id and e.userId=:idd";

			Query query = manager.createQuery(jpql);

			query.setParameter("bal", toDetails.getBalance());
			query.setParameter("id", toDetails.getUserId());
			query.setParameter("idd", sendDetails.getUserId());
			query.setParameter("bal", sendDetails.getBalance());

			query.executeUpdate();
			trans.commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			trans.rollback();
			return false;
		} finally {
			manager.close();
			emf.close();
		}	
	}
}