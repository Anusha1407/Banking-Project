package com.jfsfeb.bankingmanagementsystemhibernate.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@Data
@SuppressWarnings("serial")
@Entity
@Table(name = "user_db")
public class InfoBean implements Serializable {
	@Id
	@Column(name = "userid")
	private int userId;
	@Column
	private String name;
	@Column(name = "mobilenum")
	private long mobileNum;
	@Column
	private String email;
	@Column
	private double balance;
	@Column(name = "acct_num")
	private long acctNum;
	@ToString.Exclude
	@Column
	private String password;
	@Column
	private String role;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "reqId")
	private RequestInfoBean req;
	
//	@OneToOne(cascade = CascadeType.ALL,mappedBy = "user")
//	private TransactionInfoBean transaction;

}
