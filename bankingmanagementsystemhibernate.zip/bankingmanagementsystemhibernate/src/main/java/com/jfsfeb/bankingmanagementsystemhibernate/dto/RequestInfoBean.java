package com.jfsfeb.bankingmanagementsystemhibernate.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@SuppressWarnings("serial")
@Entity
@Table(name="request_db")
public class RequestInfoBean implements Serializable {
	@Id
	@Column(name="reqid")
	private int reqId;
	@Column(name="checkbook_req")
	private int checkBookReq;
	
	@OneToOne(cascade = CascadeType.ALL,mappedBy = "req")
	private InfoBean user;
	
}