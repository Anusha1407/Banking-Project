package com.jfsfeb.bankingmanagementsystemhibernate.dto;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.Data;


@Data
@SuppressWarnings("serial")
public class TransactionInfoBean implements Serializable {
	private int transId;
	private double balance;
	private double credit;
	private double debit;
	
//	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "userId")
//	private InfoBean user;

}
