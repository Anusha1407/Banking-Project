package com.jfsfeb.bankingmanagementsystemhibernate.factory;

import com.jfsfeb.bankingmanagementsystemhibernate.dao.AdminDao;
import com.jfsfeb.bankingmanagementsystemhibernate.dao.AdminImplDao;
import com.jfsfeb.bankingmanagementsystemhibernate.dao.UserDao;
import com.jfsfeb.bankingmanagementsystemhibernate.dao.UserImplDao;
import com.jfsfeb.bankingmanagementsystemhibernate.service.AdminService;
import com.jfsfeb.bankingmanagementsystemhibernate.service.AdminServiceImpl;
import com.jfsfeb.bankingmanagementsystemhibernate.service.UserService;
import com.jfsfeb.bankingmanagementsystemhibernate.service.UserServiceImpl;
import com.jfsfeb.bankingmanagementsystemhibernate.validation.BankingValidation;
import com.jfsfeb.bankingmanagementsystemhibernate.validation.Validation;

public class BankingFactory {

	private BankingFactory() {

	}

	public static AdminDao getAdminImplDaoInstance() {
		AdminDao adminDao = new AdminImplDao();
		return adminDao;
	}

	public static AdminService getAdminServiceImplDaoInstance() {
		AdminService adminService = new AdminServiceImpl();
		return adminService;
	}
	public static UserDao getUserImplDaoInstance() {
		UserDao userDao = new UserImplDao();
		return userDao;
	}

	public static UserService getUserServiceImplDaoInstance() {
		UserService userService = new UserServiceImpl();
		return userService;
	}

	public static BankingValidation getValidationInstance() {
		BankingValidation validation = new Validation();
		return validation;
	}
}
