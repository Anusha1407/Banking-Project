package com.jfsfeb.bankingmanagementsystemhibernate.service;

import java.util.List;

import com.jfsfeb.bankingmanagementsystemhibernate.dto.InfoBean;
import com.jfsfeb.bankingmanagementsystemhibernate.dto.RequestInfoBean;

public interface AdminService {
	public boolean adminReg(InfoBean bean);

	public InfoBean adminLogin(String email, String password);

	public InfoBean editAdminProfile(InfoBean admin);

	public boolean addUser(InfoBean user);

	public List<RequestInfoBean> reqById();

	public InfoBean getYourDetails(int Id);

	public List<InfoBean> getUserDetails();

}
