package com.jfsfeb.bankingmanagementsystemhibernate.service;


import com.jfsfeb.bankingmanagementsystemhibernate.dto.InfoBean;
import com.jfsfeb.bankingmanagementsystemhibernate.dto.RequestInfoBean;

public interface UserService {
	public boolean userReg(InfoBean user);

	public InfoBean userLogin(String user, String password);

	public InfoBean editProfile(InfoBean user);

	public RequestInfoBean checkBookReq(RequestInfoBean requ);

	public InfoBean getYourDetails(int Id);

	public boolean transferMoney(InfoBean toDetails,InfoBean sendDetails);
}
