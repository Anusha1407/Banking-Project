package com.jfsfeb.bankingmanagementsystemjdbc.controller;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.jfsfeb.bankingmanagementsystemjdbc.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystemjdbc.dto.InfoBean;
import com.jfsfeb.bankingmanagementsystemjdbc.exception.UserExceptions;
import com.jfsfeb.bankingmanagementsystemjdbc.factory.BankingFactory;
import com.jfsfeb.bankingmanagementsystemjdbc.service.AdminService;
import com.jfsfeb.bankingmanagementsystemjdbc.service.UserService;

import lombok.extern.log4j.Log4j;

@Log4j
public class App {
	public static void doReg() {

		int adminId = 0;
		String adminName = null;
		long adminMobile = 0l;
		String adminEmail = null;
		String adminPassword = null;
		int userId = 0;
		String userName = null;
		long userMobile = 0l;
		String userEmail = null;
		String userPassword = null;
		int userReqId = 0;
		long userAcctNum = 0l;
		double balance = 0f;
		String role = null;

		InfoBean userBean = null;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		do {
			try {
				log.info("************Welcome to Bancking management System************");
				log.info("Press 1 for Admin Block");
				log.info("Press 2 for User Block");
				log.info("***********************************");
				int i = scanner.nextInt();
				switch (i) {
				case 1:
					AdminService service = BankingFactory.getAdminServiceImplDaoInstance();

					do {
						try {
							log.info("********Welcome To Admin Portal********");
							log.info("You Want to Register Press 1");
							log.info("You Want to Login Press 2");
							log.info("To Exit press 3");
							log.info("***********************************");
							int choice = scanner.nextInt();
							switch (choice) {
							case 1:
								log.info("********Enter All the details to Register********");

								try {
									log.info("Enter ID :");
									adminId = scanner.nextInt();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								log.info("Enter Name :");
								adminName = scanner.next();
//							
								try {
									log.info("Enter Mobile :");
									adminMobile = scanner.nextLong();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								log.info("Enter Email :");
								adminEmail = scanner.next();

								log.info("Enter Password :");
								adminPassword = scanner.next();

								log.info("Enter Your Role :");
								role = scanner.next();

								userBean = new InfoBean();

								userBean.setUserId(adminId);
								userBean.setName(adminName);
								userBean.setMobileNum(adminMobile);
								userBean.setEmail(adminEmail);
								userBean.setPassword(adminPassword);
								userBean.setRole(role);

								try {
									boolean check = service.adminReg(userBean);
									if (check) {
										log.info("***********Register Syccessfully***********");
									} else {
										log.info("Email already exist in the Database");
									}

								} catch (UserExceptions e) {
									log.error(e.getMessage());
								}
								break;
							case 2:
								log.info("Enter Email :");
								adminEmail = scanner.next();
								log.info("Enter Password :");
								adminPassword = scanner.next();
								try {
									userBean = service.adminLogin(adminEmail, adminPassword);
									log.info("You have login successfully");

									do {
										try {
											log.info("*******Welcome To Login Page*******");
											log.info("Press 1 to Edit Your Profile ");
											log.info("Press 2 to Get the all User Details");
											log.info("Press 3 for Create User");
											log.info("Press 4 to see all the User Requests");
											log.info("Press 5 to check your details");
											log.info("To Logout Press 6");
											log.info("***********************************");

											int choice1 = scanner.nextInt();
											switch (choice1) {
											case 1:
												try {
													log.info("Select which field to change");
													log.info("1.Name");
													log.info("2.Email");
													log.info("3.Mobilenum");
													log.info("4.Password");

													int choice3 = scanner.nextInt();
													switch (choice3) {
													case 1:
														log.info("Please enter name");
														adminName = scanner.next();

														try {
															log.info("Please enter Id");
															userId = scanner.nextInt();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}

														userBean.setUserId(userId);
														userBean.setName(userName);
														try {
															userBean = service.editAdminProfile(userBean);
															userBean.setName(userName);
															log.info("*******Profile Edited Successfully*******");

														} catch (Exception e) {
															log.error("Value Already Exist");
														}

														break;
													case 2:
														log.info("Please enter Email");
														adminEmail = scanner.next();

														try {
															log.info("Please enter Id");
															userId = scanner.nextInt();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}

														userBean.setUserId(userId);
														userBean.setEmail(adminEmail);
														try {
															userBean = service.editAdminProfile(userBean);

															log.info("*******Profile Edited Successfully*******");

														} catch (UserExceptions e) {
															log.error(e.getMessage());
														}
														break;
													case 3:
														log.info("Please enter Password");
														adminPassword = scanner.next();
														try {
															log.info("Please enter Id");
															userId = scanner.nextInt();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}

														userBean.setUserId(userId);
														userBean.setPassword(adminPassword);
														try {

															userBean = service.editAdminProfile(userBean);
															log.info("*******Profile Edited Successfully*******");

														} catch (UserExceptions e) {
															log.error(e.getMessage());
														}

														break;
													case 4:
														try {
															log.info("Please enter mobilenum");
															adminMobile = scanner.nextLong();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}

														try {
															log.info("Please enter Id");
															userId = scanner.nextInt();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}
														userBean.setUserId(userId);
														userBean.setMobileNum(adminMobile);
														try {

															userBean = service.editAdminProfile(userBean);
															log.info("*******Profile Edited Successfully*******");
														} catch (UserExceptions e) {
															log.error(e.getMessage());
														}
														break;
													default:
														log.error("Invalid Choice!!Enter choice between 1-5");
														break;
													}
												} catch (InputMismatchException e) {
													log.error("Incorrect entry. Please enter above options only");
													scanner.nextLine();
												}
												break;
											case 2:
												try {
													List<InfoBean> details = service.getUserDetails();
													log.info("***********Welcome to User Details Section************");
													log.info(String.format("%-10s %-10s %-17s  %-15s  %-15s  %-15s %s",
															"UserId", "UserName", "MailId", "Password", "PhoneNumber",
															"AcctNum", "Balance"));
													for (InfoBean user : details) {
														log.info(String.format(
																"%-10s %-10s %-13s  %-15s  %-15s  %-14s  %s",
																user.getUserId(), user.getName(), user.getEmail(),
																user.getPassword(), user.getMobileNum(),
																user.getAcctNum(), user.getBalance()));
													}
												} catch (UserExceptions e) {
													log.error("No Users are available");
												}

												break;
											case 3:
												try {
													log.info("Enter ID :");
													userId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												log.info("Enter Name :");
												userName = scanner.next();

												try {
													log.info("Enter Mobile :");
													userMobile = scanner.nextLong();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												log.info("Enter Email :");
												userEmail = scanner.next();

												log.info("Enter Password :");
												userPassword = scanner.next();

												log.info("Enter Your Role :");
												role = scanner.next();

												try {
													log.info("Enter Account Number :");
													userAcctNum = scanner.nextLong();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {
													log.info("Enter Your Balance :");
													balance = scanner.nextDouble();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												userBean = new InfoBean();

												userBean.setUserId(userId);
												userBean.setName(userName);
												userBean.setMobileNum(userMobile);
												userBean.setEmail(userEmail);
												userBean.setPassword(userPassword);
												userBean.setAcctNum(userAcctNum);
												userBean.setBalance(balance);
												userBean.setRole(role);

												try {
													boolean check1 = service.addUser(userBean);
													if (check1) {

														log.info("***********User Added Syccessfully***********");
													} else {
														log.info("Email already exist");
													}
												} catch (UserExceptions e) {
													log.error(e.getMessage());
												}
												break;
											case 4:
												try {
													log.info("Requests of All User's are :");
													log.info(
															"------------------------------------------------------------------------");
													log.info("CheckBookReqId");

													List<RequestInfoBean> requestInfos = service.reqById();
													for (RequestInfoBean info1 : requestInfos) {
														log.info(info1.getCheckBookReq());
													}

												} catch (UserExceptions e) {
													log.error("No CheckBook Request's Occured");
												}

												break;

											case 5:
												try {
													log.info("Please enter Id");
													adminId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}
												try {
													InfoBean bean = service.getYourDetails(adminId);
													log.info("******Welcome to Your Details Section****");
													log.info("AdminId---------->" + bean.getUserId());
													log.info("Name------------->" + bean.getName());
													log.info("EmailId---------->" + bean.getEmail());
													log.info("Password--------->" + bean.getPassword());
													log.info("MobileNum-------->" + bean.getMobileNum());

												} catch (UserExceptions e) {
													log.error(e.getMessage());
												}

												break;
											case 6:
												doReg();
											default:
												log.error("Invalid Choice!!Enter choice between 1-6");
												break;
											}
										} catch (InputMismatchException ex) {
											log.error("Incorrect entry. Please enter above options only");
											scanner.nextLine();
										}
									} while (true);
								} catch (UserExceptions e) {
									log.error(e.getMessage());
								}
								break;
							case 3:
								doReg();
							default:
								log.error("Invalid Choice!!Enter choice between 1-3");
								break;
							}
						} catch (InputMismatchException ex) {
							log.error("Incorrect entry. Please enter above options only");
							scanner.nextLine();
						}
					} while (true);
				case 2:
					UserService userService = BankingFactory.getUserServiceImplDaoInstance();
					do {
						try {
							log.info("***********************************");
							log.info("You Want to Register Press 1");
							log.info("You Want to Login Press 2");
							log.info("press 3 to exit");
							log.info("***********************************");
							int choice = scanner.nextInt();
							switch (choice) {
							case 1:
								try {
									log.info("Enter ID :");
									userId = scanner.nextInt();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								log.info("Enter Name :");
								userName = scanner.next();

								try {
									log.info("Enter Mobile :");
									userMobile = scanner.nextLong();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								log.info("Enter Email :");
								userEmail = scanner.next();

								log.info("Enter Password :");
								userPassword = scanner.next();

								try {
									log.info("Enter Account Number :");
									userAcctNum = scanner.nextLong();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								try {
									log.info("Enter Your Balance :");
									balance = scanner.nextDouble();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}

								log.info("Enter Your Role :");
								role = scanner.next();

								userBean = new InfoBean();

								userBean.setUserId(userId);
								userBean.setName(userName);
								userBean.setMobileNum(userMobile);
								userBean.setEmail(userEmail);
								userBean.setPassword(userPassword);
								userBean.setAcctNum(userAcctNum);
								userBean.setBalance(balance);
								userBean.setRole(role);

								try {
									boolean check = userService.userReg(userBean);
									if (check) {
										log.info("***********Register Syccessfully***********");
									} else {
										log.info("Email already exist");
									}
								} catch (UserExceptions e) {
									log.error(e.getMessage());
								}
								break;
							case 2:
								log.info("Enter Email :");
								userEmail = scanner.next();
								log.info("Enter Password :");
								userPassword = scanner.next();

								try {
									userBean = userService.userLogin(userEmail, userPassword);
									log.info("You have login successfully");
									do {
										try {

											log.info("***********************************");
											log.info("Press 1 for Edit Profile Page");
											log.info("Press 2 to send check book request");
											log.info("Press 3 to View Your Profile");
											log.info("Press 4 to Transfer Money");
											log.info("Press 5 for Logout");
											log.info("***********************************");

											int choice1 = scanner.nextInt();
											switch (choice1) {
											case 1:
												try {
													log.info("***********************************");
													log.info("Select which option to change");
													log.info("1.Name");
													log.info("2.Email");
													log.info("3.Mobilenum");
													log.info("4.Password");

													int choice2 = scanner.nextInt();
													switch (choice2) {
													case 1:
														log.info("Please enter name");
														userName = scanner.next();
														try {
															log.info("Please enter Id");
															userId = scanner.nextInt();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}

														userBean.setUserId(userId);
														userBean.setName(userName);
														try {
															userService.editProfile(userBean);
															log.info("*******Profile Edited Successfully*******");

														} catch (Exception e) {
															e.printStackTrace();
															log.error("Value Already Exist");
														}
														break;
													case 2:
														log.info("Please enter Email");
														userEmail = scanner.next();
														try {
															log.info("Please enter Id");
															userId = scanner.nextInt();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}

														userBean.setUserId(userId);
														userBean.setEmail(userEmail);
														try {
															userService.editProfile(userBean);

															log.info("*******Profile Edited Successfully*******");

														} catch (Exception e) {
															e.printStackTrace();
															log.error("Value Already Exist");
														}
														break;

													case 3:
														log.info("Please enter Password");
														userPassword = scanner.next();
														try {
															log.info("Please enter Id");
															userId = scanner.nextInt();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}

														userBean.setUserId(userId);
														userBean.setPassword(userPassword);
														try {

															userService.editProfile(userBean);
															log.info("*******Profile Edited Successfully*******");

														} catch (UserExceptions e) {
															log.error(e.getMessage());
														}
														break;
													case 4:
														try {
															log.info("Please enter mobilenum");
															userMobile = scanner.nextLong();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}
														try {
															log.info("Please enter Id");
															userId = scanner.nextInt();
														} catch (InputMismatchException e) {
															scanner.nextLine();
														}
														userBean.setUserId(userId);
														userBean.setMobileNum(userMobile);
														try {

															userService.editProfile(userBean);
															log.info("*******Profile Edited Successfully*******");
														} catch (UserExceptions e) {
															log.error(e.getMessage());
														}
														break;
													default:
														log.error("Invalid Choice!!Enter choice between 1-4");
														break;
													}
												} catch (InputMismatchException ex) {
													log.info("Incorrect entry. Please enter above options only");
													scanner.nextLine();
												}
												break;
											case 2:
												try {
													log.info("Please enter your Id To Send Request");
													userId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {
													log.info("Please enter request Id To Send Request");
													userReqId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {
													RequestInfoBean req = new RequestInfoBean();
													req.setCheckBookReq(userReqId);
													@SuppressWarnings("unused")
													boolean req1 = userService.checkBookReq(req);
													System.out
															.println("*******Request hasbeen sent Successfully*******");
													log.info(
															"*******Request should be Processed with in a week*******");
												} catch (Exception e) {
													e.printStackTrace();
													log.error(
															"Request Already Sent/Check Your UserId and Try Again!!!");
												}
												break;
											case 3:
												try {
													log.info("Please enter UserId");
													userId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {
													InfoBean bean = userService.getYourDetails(userId);
													log.info("******Welcome to Your Details Section****");
													log.info("UserId-------------->" + bean.getUserId());
													log.info("Name---------------->" + bean.getName());
													log.info("EmailId------------->" + bean.getEmail());
													log.info("MobileNum----------->" + bean.getMobileNum());
													log.info("Role---------------->" + bean.getRole());
													log.info("Password------------>" + bean.getPassword());
													log.info("Account Number------>" + bean.getAcctNum());
													log.info("Current Balance----->" + bean.getBalance());
												} catch (UserExceptions e) {
													log.error(e.getMessage());
												}
												break;

											case 4:
												try {
													log.info("Enter Your ID :");
													userId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {
													log.info("Enter ID to Which you are sending :");
													userReqId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {
													log.info("Enter Amount to Transfer");
													balance = scanner.nextDouble();

												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												userBean = new InfoBean();

												userBean.setUserId(userId);

												InfoBean userBean1 = new InfoBean();
												userBean1.setUserId(userReqId);

												try {
													if (balance != 0) {
														userBean.setBalance(balance);
													} else {
														throw new UserExceptions("Amount Should be Greaterthan Zero");
													}
													boolean isValid = userService.transferMoney(userBean, userBean1);

													if (isValid) {
														log.info("Transaction Successfull");
													} else {
														log.error("Transaction Failed");
													}
												} catch (UserExceptions e) {
													log.error(e.getMessage());
												}
												break;
											case 5:
												doReg();
											default:
												log.error("Invalid Choice!!Enter choice between 1-3");
												break;
											}
										} catch (InputMismatchException ex) {
											log.error("Incorrect entry. Please enter above options only");
											scanner.nextLine();
										}
									} while (true);
								} catch (UserExceptions e) {
									log.error(e.getMessage());
								}
								break;
							case 3:
								doReg();
							default:
								log.error("Invalid Choice!!Enter choice between 1-3");
								break;
							}
						} catch (InputMismatchException e) {
							log.error("Incorrect entry. Please enter above options only");
							scanner.nextLine();
						}
					} while (true);
				default:
					log.error("Invalid Choice!!Enter choice between 1-2");
					break;
				}

			} catch (InputMismatchException e) {
				log.error("Incorrect entry. Please enter above options only");
				scanner.nextLine();
			}
		} while (true);
	}
}