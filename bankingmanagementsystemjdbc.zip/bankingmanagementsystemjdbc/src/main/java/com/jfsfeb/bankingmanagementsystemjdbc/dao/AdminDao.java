package com.jfsfeb.bankingmanagementsystemjdbc.dao;

import java.util.List;

import com.jfsfeb.bankingmanagementsystemjdbc.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystemjdbc.dto.InfoBean;


public interface AdminDao {
	public boolean adminReg(InfoBean bean);

	public InfoBean adminLogin(String email, String password);

	public InfoBean editAdminProfile(InfoBean admin);

	public boolean addUser(InfoBean user);

	public List<RequestInfoBean> reqById();

	public InfoBean getYourDetails(int Id);

	public List<InfoBean> getUserDetails();

}
