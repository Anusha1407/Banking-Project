package com.jfsfeb.bankingmanagementsystemjdbc.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.jfsfeb.bankingmanagementsystemjdbc.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystemjdbc.exception.UserExceptions;
import com.jfsfeb.bankingmanagementsystemjdbc.utility.JdbcUtility;
import com.jfsfeb.bankingmanagementsystemjdbc.dto.InfoBean;

public class AdminImplDao implements AdminDao {

	JdbcUtility connection = new JdbcUtility();

	@Override
	public boolean adminReg(InfoBean bean) {
		try {
			Connection con = connection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(connection.getQuery("adminReg"));

			prepstmt.setInt(1, bean.getUserId());
			prepstmt.setString(2, bean.getName());
			prepstmt.setLong(3, bean.getMobileNum());
			prepstmt.setString(4, bean.getEmail());
			prepstmt.setString(5, bean.getRole());
			prepstmt.setString(6, bean.getPassword());

			prepstmt.executeUpdate();

		} catch (Exception e) {
			throw new UserExceptions("Can't Add New admin, as Admin Already Exists");
		}
		return true;
	}

	@Override
	public InfoBean adminLogin(String email, String password) {
		InfoBean admin = new InfoBean();

		try {
			Connection con = connection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(connection.getQuery("adminLogin"));
			prepstmt.setString(1, email);
			prepstmt.setString(2, password);
			try {
				ResultSet rs = prepstmt.executeQuery();
				while (rs.next()) {
					admin.setEmail(rs.getString("email"));
					admin.setPassword(rs.getString("password"));

					return admin;
				}

			} catch (Exception e) {
				throw new UserExceptions("Invalid Credentials");

			}
		} catch (Exception e) {
			throw new UserExceptions("Invalid Credentials");

		}
		throw new UserExceptions("Invalid Credentials");
	}

	@Override
	public InfoBean editAdminProfile(InfoBean admin) {
		try {
			Connection con = connection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(connection.getQuery("editProfile"));

			prepstmt.setString(1, admin.getName());
			prepstmt.setString(2, admin.getEmail());
			prepstmt.setString(3, admin.getPassword());
			prepstmt.setLong(4, admin.getMobileNum());
			prepstmt.setInt(5, admin.getUserId());

			prepstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			throw new UserExceptions("value already exist");

		}
		return null;
	}

	@Override
	public boolean addUser(InfoBean user) {
		try {
			Connection con = connection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(connection.getQuery("userReg"));

			prepstmt.setInt(1, user.getUserId());
			prepstmt.setString(2, user.getName());
			prepstmt.setString(3, user.getEmail());
			prepstmt.setLong(4, user.getMobileNum());
			prepstmt.setString(5, user.getPassword());
			prepstmt.setString(6, user.getRole());
			prepstmt.setLong(7, user.getAcctNum());
			prepstmt.setDouble(8, user.getBalance());

		} catch (Exception e) {
			throw new UserExceptions("Already Exist");
		}
		return true;
	}

	@Override
	public List<RequestInfoBean> reqById() {
		List<RequestInfoBean> userInfo = new ArrayList<RequestInfoBean>();
		try (Connection conn = connection.getConnection();
				PreparedStatement prepstmt = conn.prepareStatement(connection.getQuery("getReqdb"));
				ResultSet rs = prepstmt.executeQuery()) {
			while (rs.next()) {
				RequestInfoBean info = new RequestInfoBean();
				info.setCheckBookReq(rs.getInt("UserId"));
				userInfo.add(info);
			}
			if (userInfo.isEmpty()) {
				throw new UserExceptions("No CheckBook requests are Available");
			} else {
				return userInfo;
			}
		} catch (Exception e) {
			throw new UserExceptions(e.getMessage());
		}
	}

	@Override
	public InfoBean getYourDetails(int Id) {
		InfoBean info = new InfoBean();
		try {
			Connection con = connection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(connection.getQuery("getYourDetails"));

			prepstmt.setInt(1, Id);
			ResultSet rs = prepstmt.executeQuery();
			if (rs.next()) {
			info.setUserId(rs.getInt("UserId"));
			info.setName(rs.getString("name"));
			info.setEmail(rs.getString("email"));
			info.setMobileNum(rs.getLong("mobileNum"));
			info.setPassword(rs.getString("password"));
			info.setRole(rs.getString("role"));
			return info;
			}
		} catch (Exception e) {
			throw new UserExceptions(e.getMessage());
		}
		return null;
	}

	@Override
	public List<InfoBean> getUserDetails() {
		List<InfoBean> userInfo = new ArrayList<InfoBean>();
		try (Connection conn = connection.getConnection();
				PreparedStatement prepstmt = conn.prepareStatement(connection.getQuery("getUserDetails"));
				ResultSet rs = prepstmt.executeQuery()) {
			while (rs.next()) {
				InfoBean info = new InfoBean();

				info.setUserId(rs.getInt("UserId"));
				info.setName(rs.getString("name"));
				info.setEmail(rs.getString("email"));
				info.setMobileNum(rs.getLong("mobileNum"));
				info.setPassword(rs.getString("password"));
				info.setRole(rs.getString("role"));
				info.setAcctNum(rs.getLong("acct_Num"));
				info.setBalance(rs.getDouble("balance"));

				userInfo.add(info);
			}
			if (userInfo.isEmpty()) {
				throw new UserExceptions("No User's Are Available");
			} else {
				return userInfo;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new UserExceptions(e.getMessage());
		}
	}

}
