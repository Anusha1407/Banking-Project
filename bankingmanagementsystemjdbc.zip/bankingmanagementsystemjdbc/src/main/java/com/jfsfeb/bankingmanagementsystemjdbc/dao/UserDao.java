package com.jfsfeb.bankingmanagementsystemjdbc.dao;


import com.jfsfeb.bankingmanagementsystemjdbc.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystemjdbc.dto.InfoBean;

public interface UserDao {

	public boolean userReg(InfoBean user);

	public InfoBean userLogin(String email, String pass);

	public InfoBean editProfile(InfoBean user);

	public boolean checkBookReq(RequestInfoBean requ);

	public InfoBean getYourDetails(int Id);

	public boolean transferMoney(InfoBean toDetails,InfoBean sendDetails);

}
