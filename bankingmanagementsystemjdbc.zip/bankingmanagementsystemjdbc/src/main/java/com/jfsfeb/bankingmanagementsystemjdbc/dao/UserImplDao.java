package com.jfsfeb.bankingmanagementsystemjdbc.dao;

import com.jfsfeb.bankingmanagementsystemjdbc.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystemjdbc.exception.UserExceptions;
import com.jfsfeb.bankingmanagementsystemjdbc.utility.JdbcUtility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.jfsfeb.bankingmanagementsystemjdbc.dto.InfoBean;

public class UserImplDao implements UserDao {

	JdbcUtility connection = new JdbcUtility();

	@Override
	public boolean userReg(InfoBean user) {
		try {
			Connection con = connection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(connection.getQuery("userReg"));

			prepstmt.setInt(1, user.getUserId());
			prepstmt.setString(2, user.getName());
			prepstmt.setLong(3, user.getMobileNum());
			prepstmt.setString(4, user.getEmail());
			prepstmt.setDouble(5, user.getBalance());
			prepstmt.setLong(6, user.getAcctNum());
			prepstmt.setString(7, user.getRole());
			prepstmt.setString(8, user.getPassword());

			prepstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			throw new UserExceptions("Already Exist");
		}
		return true;
	}

	@Override
	public InfoBean userLogin(String email, String pass) {
		InfoBean user = new InfoBean();

		try {
			Connection con = connection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(connection.getQuery("userLogin"));
			prepstmt.setString(1, email);
			prepstmt.setString(2, pass);
			try {
				ResultSet rs = prepstmt.executeQuery();
				while (rs.next()) {
					user.setEmail(rs.getString("email"));
					user.setPassword(rs.getString("password"));
					return user;
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new UserExceptions("Invalid Login Credentials");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new UserExceptions("Invalid Login Credentials");
		}
		throw new UserExceptions("Invalid Login Credentials");
	}

	@Override
	public InfoBean editProfile(InfoBean user) {
		try {
			Connection con = connection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(connection.getQuery("editProfile"));

			prepstmt.setString(1, user.getName());
			prepstmt.setString(2, user.getEmail());
			prepstmt.setString(3, user.getPassword());
			prepstmt.setLong(4, user.getMobileNum());
			prepstmt.setInt(5, user.getUserId());

			prepstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			throw new UserExceptions("value already exist");

		}
		return null;
	}

	@Override
	public boolean checkBookReq(RequestInfoBean requ) {
		try {
			Connection con = connection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(connection.getQuery("setReqId"));

			prepstmt.setInt(1, requ.getCheckBookReq());
			prepstmt.setInt(2, requ.getRedId());

			prepstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			throw new UserExceptions("Already Exist");
		}
		return true;
	}

	@Override
	public InfoBean getYourDetails(int Id) {
		try {
			Connection con = connection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(connection.getQuery("getYourDetails"));
			prepstmt.setInt(1, Id);
			ResultSet rs = prepstmt.executeQuery();

			if (rs.next()) {
				InfoBean info = new InfoBean();

				info.setUserId(rs.getInt("UserId"));
				info.setName(rs.getString("name"));
				info.setEmail(rs.getString("email"));
				info.setMobileNum(rs.getLong("mobileNum"));
				info.setPassword(rs.getString("password"));
				info.setRole(rs.getString("role"));
				info.setAcctNum(rs.getLong("acct_Num"));
				info.setBalance(rs.getDouble("balance"));

				return info;
			}

		} catch (Exception e) {
			throw new UserExceptions(e.getMessage());
		}
		return null;
	}

	@Override
	public boolean transferMoney(InfoBean toDetails, InfoBean sendDetails) {
		try {
			Connection con = connection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(connection.getQuery("transaction"));

			prepstmt.setDouble(1, toDetails.getBalance());
			prepstmt.setInt(2, toDetails.getUserId());
			prepstmt.setInt(3, sendDetails.getUserId());
			prepstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			throw new UserExceptions("Entered Id Should match Check again!!");

		}
		return true;
	}

}