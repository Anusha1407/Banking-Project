package com.jfsfeb.bankingmanagementsystemjdbc.dto;

import java.io.Serializable;

import lombok.Data;

@Data
@SuppressWarnings("serial")
public class RequestInfoBean implements Serializable {
	private int redId;
	private long acctReq;
	private int checkBookReq;
}