package com.jfsfeb.bankingmanagementsystemjdbc.exception;

@SuppressWarnings("serial")
public class UserExceptions extends RuntimeException {

	public UserExceptions(String msg) {
		super(msg);
	}
}
