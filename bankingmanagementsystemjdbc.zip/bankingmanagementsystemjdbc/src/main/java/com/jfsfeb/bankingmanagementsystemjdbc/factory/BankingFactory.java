package com.jfsfeb.bankingmanagementsystemjdbc.factory;

import com.jfsfeb.bankingmanagementsystemjdbc.dao.AdminDao;
import com.jfsfeb.bankingmanagementsystemjdbc.dao.AdminImplDao;
import com.jfsfeb.bankingmanagementsystemjdbc.dao.UserDao;
import com.jfsfeb.bankingmanagementsystemjdbc.dao.UserImplDao;
import com.jfsfeb.bankingmanagementsystemjdbc.service.AdminService;
import com.jfsfeb.bankingmanagementsystemjdbc.service.AdminServiceImpl;
import com.jfsfeb.bankingmanagementsystemjdbc.service.UserService;
import com.jfsfeb.bankingmanagementsystemjdbc.service.UserServiceImpl;
import com.jfsfeb.bankingmanagementsystemjdbc.validation.BankingValidation;
import com.jfsfeb.bankingmanagementsystemjdbc.validation.Validation;

public class BankingFactory {

	private BankingFactory() {

	}

	public static AdminDao getAdminImplDaoInstance() {
		AdminDao adminDao = new AdminImplDao();
		return adminDao;
	}

	public static AdminService getAdminServiceImplDaoInstance() {
		AdminService adminService = new AdminServiceImpl();
		return adminService;
	}
	public static UserDao getUserImplDaoInstance() {
		UserDao userDao = new UserImplDao();
		return userDao;
	}

	public static UserService getUserServiceImplDaoInstance() {
		UserService userService = new UserServiceImpl();
		return userService;
	}

	public static BankingValidation getValidationInstance() {
		BankingValidation validation = new Validation();
		return validation;
	}
}
