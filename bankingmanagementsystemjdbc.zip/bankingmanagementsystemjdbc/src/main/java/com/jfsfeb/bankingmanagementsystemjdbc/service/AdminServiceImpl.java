package com.jfsfeb.bankingmanagementsystemjdbc.service;

import java.util.List;

import com.jfsfeb.bankingmanagementsystemjdbc.dao.AdminDao;
import com.jfsfeb.bankingmanagementsystemjdbc.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystemjdbc.dto.InfoBean;
import com.jfsfeb.bankingmanagementsystemjdbc.factory.BankingFactory;
import com.jfsfeb.bankingmanagementsystemjdbc.validation.BankingValidation;

public class AdminServiceImpl implements AdminService {
	AdminDao dao = BankingFactory.getAdminImplDaoInstance();
	BankingValidation validation = BankingFactory.getValidationInstance();

	@Override
	public boolean adminReg(InfoBean bean) {
		if (validation.validatedId(bean.getUserId())) {
			if (validation.validatedName(bean.getName())) {
				if (validation.validatedEmail(bean.getEmail())) {
					if (validation.validatedMobile(bean.getMobileNum())) {
						if (validation.validatedPassword(bean.getPassword())) {
							return dao.adminReg(bean);
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public InfoBean adminLogin(String email, String password) {
		if (validation.validatedEmail(email)) {
			if (validation.validatedPassword(password)) {
				return dao.adminLogin(email, password);
			}
		}
		return null;
	}

	@Override
	public InfoBean editAdminProfile(InfoBean bean) {
		if (validation.validatedId(bean.getUserId()) ||validation.validatedName(bean.getName()) || validation.validatedEmail(bean.getEmail())
				|| validation.validatedMobile(bean.getMobileNum())
				|| validation.validatedPassword(bean.getPassword())) {

			InfoBean add = new InfoBean();

			add = dao.getYourDetails(bean.getUserId());
			add.setName(bean.getName());
			add.setEmail(bean.getEmail());
			add.setMobileNum(bean.getMobileNum());
			add.setPassword(bean.getPassword());
			return dao.editAdminProfile(bean);
		}
		return null;
	}

	@Override
	public boolean addUser(InfoBean user) {
		if (validation.validatedId(user.getUserId())) {
			if (validation.validatedName(user.getName())) {
				if (validation.validatedEmail(user.getEmail())) {
					if (validation.validatedMobile(user.getMobileNum())) {
						if (validation.validatedPassword(user.getPassword())) {
							if (validation.validatedAcctNo(user.getAcctNum())) {
								if (validation.validatedBalance(user.getBalance())) {
									return dao.addUser(user);
								}
							}
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public List<InfoBean> getUserDetails() {
		return dao.getUserDetails();
	}

	@Override
	public List<RequestInfoBean> reqById() {
		return dao.reqById();
	}

	@Override
	public InfoBean getYourDetails(int Id) {
		if (validation.validatedId(Id)) {
			return dao.getYourDetails(Id);
		}
		return null;
	}

}
