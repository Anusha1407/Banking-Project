package com.jfsfeb.bankingmanagementsystemjdbc.service;


import com.jfsfeb.bankingmanagementsystemjdbc.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystemjdbc.dto.InfoBean;

public interface UserService {
	public boolean userReg(InfoBean user);

	public InfoBean userLogin(String user, String password);

	public InfoBean editProfile(InfoBean user);

	public boolean checkBookReq(RequestInfoBean requ);

	public InfoBean getYourDetails(int Id);

	public boolean transferMoney(InfoBean toDetails,InfoBean sendDetails);
}
