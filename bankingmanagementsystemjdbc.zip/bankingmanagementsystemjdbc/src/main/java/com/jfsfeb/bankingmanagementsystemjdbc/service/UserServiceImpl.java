package com.jfsfeb.bankingmanagementsystemjdbc.service;

import com.jfsfeb.bankingmanagementsystemjdbc.dao.UserDao;
import com.jfsfeb.bankingmanagementsystemjdbc.dao.UserImplDao;
import com.jfsfeb.bankingmanagementsystemjdbc.dto.RequestInfoBean;
import com.jfsfeb.bankingmanagementsystemjdbc.dto.InfoBean;
import com.jfsfeb.bankingmanagementsystemjdbc.exception.UserExceptions;
import com.jfsfeb.bankingmanagementsystemjdbc.factory.BankingFactory;
import com.jfsfeb.bankingmanagementsystemjdbc.validation.BankingValidation;

public class UserServiceImpl implements UserService {
	UserDao dao = new UserImplDao();
	BankingValidation validation = BankingFactory.getValidationInstance();

	@Override
	public boolean userReg(InfoBean user) {
		if (validation.validatedId(user.getUserId())) {
			if (validation.validatedName(user.getName())) {
				if (validation.validatedEmail(user.getEmail())) {
					if (validation.validatedMobile(user.getMobileNum())) {
						if (validation.validatedPassword(user.getPassword())) {
							if (validation.validatedAcctNo(user.getAcctNum())) {
								if (validation.validatedBalance(user.getBalance())) {
									return dao.userReg(user);
								}
							}
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public InfoBean userLogin(String user, String password) {
		if (validation.validatedEmail(user)) {
			if (validation.validatedPassword(password)) {
				return dao.userLogin(user, password);
			} else {
				throw new UserExceptions("Enter Proper EmailId");
			}
		}
		throw new UserExceptions(
				"Password should contain atleast 6 characters ,one uppercase,one lowercase,one number and one special symbol(@#$%?!)");
	}

	@Override
	public InfoBean editProfile(InfoBean user) {
		if (validation.validatedId(user.getUserId()) || validation.validatedName(user.getName())
				|| validation.validatedEmail(user.getEmail()) || validation.validatedMobile(user.getMobileNum())
				|| validation.validatedPassword(user.getPassword())) {
			InfoBean add = new InfoBean();

			add = dao.getYourDetails(user.getUserId());
			add.setName(user.getName());
			add.setEmail(user.getEmail());
			add.setMobileNum(user.getMobileNum());
			add.setPassword(user.getPassword());
			return dao.editProfile(add);
		}
		return null;
	}

	@Override
	public boolean checkBookReq(RequestInfoBean req) {
		if (validation.validatedId(req.getCheckBookReq())) {
			return dao.checkBookReq(req);
		}
		return false;
	}

	@Override
	public InfoBean getYourDetails(int Id) {
		if (validation.validatedId(Id)) {
			return dao.getYourDetails(Id);
		}
		return null;
	}

	@Override
	public boolean transferMoney(InfoBean toDetails, InfoBean sendDetails) {

		if (validation.validatedId(toDetails.getUserId())) {
			if (validation.validatedId(sendDetails.getUserId())) {
				if (validation.validatedBalance(toDetails.getBalance())) {

					InfoBean user1 = new InfoBean();
					InfoBean user2 = new InfoBean();
					user1 = dao.getYourDetails(toDetails.getUserId());
					user2 = dao.getYourDetails(sendDetails.getUserId());

					if (user1.getBalance() >= toDetails.getBalance()) {
						double val = user1.getBalance() - toDetails.getBalance();
						double val1 = user2.getBalance() + toDetails.getBalance();
						user1.setBalance(val);
						user2.setBalance(val1);

						return dao.transferMoney(user1, user2);
					} else {
						throw new UserExceptions("Insufficient Balance");
					}

				}
			}
		}
		return false;
	}

}
