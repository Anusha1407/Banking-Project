package com.jfsfeb.bankingmanagementsystemjdbc.utility;

import java.io.FileInputStream;
import java.sql.*;
import java.util.Properties;

public class JdbcUtility {
	public Connection getConnection() {
		Connection conn = null;
		try {
			FileInputStream inputStream = new FileInputStream("bank.properties");
			Properties properties = new Properties();
			properties.load(inputStream);
			Class.forName(properties.getProperty("Driver"));
			conn = DriverManager.getConnection(properties.getProperty("dbUrl"));
			return conn;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public String getQuery(String baseQuery) {
		String query = null;
		FileInputStream inputStream;
		try {
			inputStream = new FileInputStream("bank.properties");
			Properties properties = new Properties();
			properties.load(inputStream);
			query = properties.getProperty(baseQuery);
			return query;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
