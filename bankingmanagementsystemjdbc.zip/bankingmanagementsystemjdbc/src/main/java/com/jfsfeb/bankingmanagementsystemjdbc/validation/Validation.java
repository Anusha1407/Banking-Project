package com.jfsfeb.bankingmanagementsystemjdbc.validation;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jfsfeb.bankingmanagementsystemjdbc.exception.UserExceptions;

public class Validation implements BankingValidation {
	
	public boolean validatedId(int id) throws UserExceptions {
		String idRegEx = "[0-9]{1}[0-9]{5}";
		boolean result = false;
		if (Pattern.matches(idRegEx, String.valueOf(id))) {
			result = true;
		} else {
			throw new UserExceptions("Id should contains exactly 6 digits");
		}
		return result;
	}

	public boolean validatedName(String name) throws UserExceptions {
		String nameRegEx = "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{0,}$";
		boolean result = false;
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(name);
		if (matcher.matches()) {
			result = true;
		} else {
			throw new UserExceptions("Name should  contains only Alphabates");
		}
		return result;
	}

	public boolean validatedMobile(long regMobile) throws UserExceptions {
		String mobileRegEx = "(0/91)?[6-9][0-9]{9}";
		boolean result = false;
		if (Pattern.matches(mobileRegEx, String.valueOf(regMobile))) {
			result = true;
		} else {
			throw new UserExceptions("Mobile Number  will start with  6 or 9 and It should contains 10 numbers");
		}
		return result;
	}

	public boolean validatedAcctNo(long Acctnum) throws UserExceptions {
		String acctNumRegEx = "[0-9]{1}[0-9]{13}";
		boolean result = false;
		if (Pattern.matches(acctNumRegEx, String.valueOf(Acctnum))) {
			result = true;
		} else {
			throw new UserExceptions("Account Number should contains exactly 14 digits");
		}
		return result;
	}

	public boolean validatedBalance(double balance) throws UserExceptions {
		String balRegEx = "^(0|[1-9]\\d*)(\\.\\d+)?$";
		boolean result = false;
		if (Pattern.matches(balRegEx, String.valueOf(balance))) {
			result = true;
		} else {
			throw new UserExceptions(
					"Entered Amount Should be a Positive number and it should be Lessthan One Million");
		}
		return result;
	}

	public boolean validatedEmail(String email) throws UserExceptions {
		String emailRegEx = "\\b[a-z0-9._%-]+@[a-z]+\\.[a-z]{2,4}\\b";
		boolean result = false;
		Pattern pattern = Pattern.compile(emailRegEx);
		Matcher matcher = pattern.matcher(email);
		if (matcher.matches()) {
			result = true;
		} else {
			throw new UserExceptions("Enter proper email ");
		}
		return result;
	}

	public boolean validatedPassword(String password) throws UserExceptions {
		String passwordRegEx = "((?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%?!]).{6,20})";
		boolean result = false;
		Pattern pattern = Pattern.compile(passwordRegEx);
		Matcher matcher = pattern.matcher(password);
		if (matcher.matches()) {
			result = true;
		} else {
			throw new UserExceptions(
					"Password should contain atleast 6 characters ,one uppercase,one lowercase,one number and one special symbol(@#$%?!)");
		}
		return result;
	}
}